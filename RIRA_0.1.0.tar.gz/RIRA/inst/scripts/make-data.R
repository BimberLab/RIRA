
for (version in c('0.1.0')) {
  seuratObj <- RIRA::GetRiraCountMatrix(version)

}
