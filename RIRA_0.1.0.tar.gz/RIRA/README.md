# RIRA

## Rhesus Immunome Reference Atlas (RIRA): A multi-tissue single-cell landscape of immune cells

Code for utility of RIRA such as classification of cell types/phenotypes


Eisa Mahyari1, Abigail B Ventura1, Eric McDonald1, Gregory J Boggy1, GW McElfresh1, Scott G Hansen2, Louis J Picker2, Benjamin N Bimber1,*
* Corresponding author: Email: bimber@ohsu.edu. Phone: 503-418-2755
1 Oregon National Primate Research Center, Oregon Health and Science University, Beaverton, OR, 97006, USA 
2 Vaccine and Gene Therapy Institute, Oregon Health and Science University, Beaverton, OR, 97006, USA
