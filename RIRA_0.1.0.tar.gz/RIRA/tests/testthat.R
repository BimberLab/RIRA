library(testthat)
library(RIRA_classification)

test_check("RIRA_classification", reporter = "progress")