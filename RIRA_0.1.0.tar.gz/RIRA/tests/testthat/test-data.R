context("RawData")

test_that("Atlas loading works", {

})