
.GetLatestVersion <- function(){
  return(packageVersion('RIRA'))
}